﻿using FuncionariosWeb.Models;
using Microsoft.EntityFrameworkCore;

namespace FuncionariosWeb.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
      : base(options)
        { }
        public DbSet<Funcionario> Funcionarios { get; set; }
    }
}
