﻿namespace FuncionariosWeb.Models
{
    public enum Departamento
    {
        TI,
        RH,
        Contabilidade,
        Marketing,
        Vendas
    }
}
